fn main() {
    println!("hello");
}